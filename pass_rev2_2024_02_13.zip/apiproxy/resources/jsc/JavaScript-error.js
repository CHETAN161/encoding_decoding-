var username = context.getVariable("request.header.username");
var password = context.getVariable("request.header.password");
var res;


if(username != "chetan" || password != "1234" )
{
    res ={
        Error :"username or password is incorrect"
    };
}

context.setVariable("Error",JSON.stringify(res));