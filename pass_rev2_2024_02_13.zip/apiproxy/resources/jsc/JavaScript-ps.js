var proxypathsuffix = context.getVariable("proxy.pathsuffix");
var result;

if (proxypathsuffix == "/manish" || proxypathsuffix == "/pass_chetan") {
    var passportNumber = context.getVariable("passportNo");
    

    if (passportNumber === "S3733862") {
        result = {
            "Validation": "true",
            "Message": "Hello" + proxypathsuffix,
            "response": {
                "result": {
                    "passportNumber": {
                        "passportNumberFromSource": "S3733862",
                        "passportNumberMatch": true
                    },
                    "applicationDate": "14/05/2018",
                    "typeOfApplication": "Tatkaal",
                    "dateOfIssue": {
                        "dispatchedOnFromSource": "14/05/2018",
                        "dateOfIssueMatch": true
                    },
                    "name": {
                        "nameScore": 1,
                        "nameMatch": true,
                        "surnameFromPassport": "SHIRHATTI",
                        "nameFromPassport": "OMKAR MILIND"
                    }
                }
            }
        };
    } else if (passportNumber === "S3733863") {
        result = {
            "Validation": "true",
            "Message": "Hello" + proxypathsuffix,
            "response": {
                "result": {
                    "passportNumber": {
                        "passportNumberFromSource": "S3733863",
                        "passportNumberMatch": true
                    },
                    "applicationDate": "14/05/2018",
                    "typeOfApplication": "Temp",
                    "dateOfIssue": {
                        "dispatchedOnFromSource": "10/05/2019",
                        "dateOfIssueMatch": true
                    },
                    "name": {
                        "nameScore": 1,
                        "nameMatch": true,
                        "surnameFromPassport": "yenam",
                        "nameFromPassport": "sai chakradhar"
                    }
                }
            }
        };
    } else {
        result = {
            "Validation": "false",
            "Message": "Invalid passport NO"
        };
    }
} else {
    result = {
        "Validation": "false",
        "Message": "Invalid Data"
    };
}

context.setVariable("result", JSON.stringify(result));
context.setVariable("result", JSON.stringify(result));
